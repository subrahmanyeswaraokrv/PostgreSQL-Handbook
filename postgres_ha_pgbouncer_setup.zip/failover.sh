#!/bin/bash
# Promote standby to primary and update PgBouncer config

PGDATA="/var/lib/postgresql/15/main"

echo "[INFO] Promoting standby to primary..."
sudo -u postgres pg_ctl -D "$PGDATA" promote

sleep 5

echo "[INFO] Updating PgBouncer config..."
sed -i 's/host=.*/host=192.168.1.11/' /etc/pgbouncer/pgbouncer.ini
sudo systemctl restart pgbouncer