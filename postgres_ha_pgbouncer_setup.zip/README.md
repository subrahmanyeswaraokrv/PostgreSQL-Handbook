# PostgreSQL High Availability with PgBouncer and Custom Failover Scripts

## Overview

This setup provides High Availability (HA) for PostgreSQL using streaming replication and PgBouncer as a connection pooler. A failover script is used to promote the standby to primary and update PgBouncer configuration.

## Components
- PostgreSQL (Primary and Standby)
- Streaming Replication
- PgBouncer
- Custom Failover Script

## Architecture

```
           +------------------+
           |   Application    |
           |     Clients      |
           +--------+---------+
                    |
                    v
           +------------------+
           |    PgBouncer     |
           | (on virtual IP)  |
           +--------+---------+
                    |
        +-----------+------------+
        |                        |
+----------------+     +----------------+
| PostgreSQL Node A |   | PostgreSQL Node B |
|    (Primary)      |   |   (Standby)       |
+------------------+   +-------------------+
```

## Setup Instructions

Refer to individual configuration and script files in this bundle.

## Failover Test

1. Stop primary node PostgreSQL.
2. Run `failover.sh` on standby.
3. PgBouncer will point to the new primary.