#!/bin/bash

PGHOST=192.168.1.10
PGPORT=5432

pg_isready -h $PGHOST -p $PGPORT
if [ $? -ne 0 ]; then
    echo "[WARN] Primary down, triggering failover..."
    /usr/local/bin/failover.sh
fi